----------------------------------------
--- Discord Whitelist, Made by FAXES ---
----------------------------------------

fx_version 'bodacious'
game 'gta5'
server_only 'yes'

author 'FAXES'
description 'Hate updating those ACE Permission white-lists? Well just use Discord! Now you can thanks to this script, and @IllusiveTeas. So keep white lists easy and breezy. This script checks the connecting players Discord roles and checks whether they have the specified role.'

server_script 'server.js'

server_export 'getRoles'
server_export 'userHasRole'
server_export 'getName'