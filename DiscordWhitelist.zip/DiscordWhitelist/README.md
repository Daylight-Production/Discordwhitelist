### Daylight production #### 

 hello! I have created a discord whitelist so people can whitelist others with a discord role.
to contact for support head ovet to https://discord.gg/vsbBwxeYMk

** instaltion ** 

Drag this file into the resources file. go to server.cfg.

then type 'start DiscordWhitelist'
then you can head over to DiscordWhitelist/server.js and you can customize everything there!